1) اعمل مستودع جديد على github.com
2) ارفع كل الملفات دي (بما فيهم مجلد .github)
3) من تبويب Actions شغّل Build APK
4) نزّل الملف masalsalaty-apk من نتيجة التشغيل، وفيه app-debug.apk
